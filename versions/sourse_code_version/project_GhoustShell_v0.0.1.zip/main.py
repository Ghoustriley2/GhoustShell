import os
from colorama import Fore, Back, init, Style
import time as t
from tqdm import tqdm
from core.help import H
from core.system import MAIN
from FileManager.FMfunction import *

banner_a = '''            ▄▄                                                 ▄▄                  ▄▄    ▄▄'''
banner_b = '''  ▄▄█▀▀▀█▄████                                    ██   ▄█▀▀▀█▄███                ▀███  ▀███'''
banner_c = '''▄██▀     ▀█ ██                                    ██  ▄██    ▀███                  ██    ██'''
banner_d = '''██▀       ▀ ███████▄   ▄██▀██▄▀███  ▀███  ▄██▀████████▀███▄    ███████▄   ▄▄█▀██   ██    ██'''
banner_e = '''██          ██    ██  ██▀   ▀██ ██    ██  ██   ▀▀ ██    ▀█████▄██    ██  ▄█▀   ██  ██    ██'''
banner_g = '''██▄    ▀██████    ██  ██     ██ ██    ██  ▀█████▄ ██  ▄     ▀████    ██  ██▀▀▀▀▀▀  ██    ██'''
banner_h = '''▀██▄     ██ ██    ██  ██▄   ▄██ ██    ██  █▄   ██ ██  ██     ████    ██  ██▄    ▄  ██    ██'''
banner_j = '''▀▀███████████  ████▄ ▀█████▀  ▀████▀███▄██████▀ ▀████▀█████▀████  ████▄ ▀█████▀▄████▄▄████▄'''
banners = [banner_a, banner_b, banner_c, banner_d, banner_e, banner_g, banner_h, banner_j]

line = '---------------------------------------------------------------------------------------------------'

def banner_print():
    for i in banners:
        print(Fore.GREEN + i)
        t.sleep(0.3)
    print(Fore.GREEN + "\n")
    print(Fore.GREEN + line)
    for i in tqdm(range(100), desc=Fore.GREEN + "загрузка", ncols=100):
        t.sleep(0.05)
    print(Fore.GREEN + line)
    t.sleep(3.5)
    os.system("cls")
    print(Fore.GREEN + line)
    tab = "\t"
    print(tab * 5 + Fore.GREEN + "    welcome!")
    print(tab * 5 + Fore.GREEN + " GhoustShell v0.0.1")
    print(Fore.GREEN + line)
    t.sleep(2)

banner_print()

version_info = Fore.GREEN + """
version: v0.0.1 (beta)
price: free
name: GhoustShell
"""

def I():
    print(version_info)

print("\n", version_info)
run = True

while run == True:
    Cm = input(f"<GhoustLine>: ")
    t.sleep(2)
    if Cm == "H" or Cm == "help":
        H()
    elif Cm == "Info" or Cm == "I" or Cm == "info" or Cm == "INFO":
        I()
    elif Cm == "E" or Cm == "Exit" or Cm == "exit":
        run = False
    elif Cm == "ls" or Cm == "L":
        L()
    elif Cm == "M" or Cm == "mkdir" or Cm == "Mkdir":
        M()
    elif Cm == "dd" or Cm == "DD" or Cm == "deldir":
        DD()
    elif Cm == "cd" or Cm == "Cd" or Cm == "C":
        CD()
    elif Cm == "lst" or Cm == "Lst" or Cm == "list" or Cm == "LST":
        LST()
    elif Cm == "RM" or Cm == "rm" or Cm == "remove":
        RM()
    elif Cm == "CP" or Cm == "cp" or Cm == "Cp" or Cm == "copy":
        CP()
    elif Cm == "Sys" or Cm == "SYS" or Cm == "sys" or Cm == "system":
        MAIN()
    else:
        print("error")