import os
import time as t

def H():
    Cm_list = """
        H or help - помощь по командам
        L or ls - показать текущюю директорию
        M or Mkdir - создать папку в текущей директории
        C or cd - зайти в папку по направлению path
        DD or deldir - удалить папку (пустую)
        RM or remove - удалить файл
        LST or list - посмотреть все файлы в текущей папке
        CP or copy - копировать файл из одного места в другое
        SYS or system - всё что можно получить из инофрмации о вашей системе (beta)
        """
    print(Cm_list)