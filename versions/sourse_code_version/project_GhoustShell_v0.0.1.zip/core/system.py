import os
def os_name():
    print(os.name)
def os_system_info():
    os.cpu_count()
def MAIN():
    print("имя платформы системы: ")
    os_name()
    print("\n")
    print("CPU ядра: ")
    print(os_system_info())
    print("\n")
    print("всё что можно заполучить в этой версии.")
