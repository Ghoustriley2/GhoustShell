import os
import shutil as s

def DD():
    folder_path = input("folder path: ")
    os.rmdir(folder_path)

def L():
    local_path = os.getcwd()
    print(local_path)

def CD():
    path = input("your path to folder: ")
    os.chdir(path)

def M():
    folder_name = input("folder name: ")
    os.mkdir(folder_name)
    print("folder as created.")

def LST():
    local_path = os.getcwd()
    os.listdir(local_path)

def RM():
    file_name = input("file name: ")
    os.remove(file_name)

def CP():
    cp_1 = input("путь файла который нужно скопировать: ")
    cp_2 = input("путь куда вставлять файл: ")
    s.copy2(cp_1, cp_2)